create materialized view D_LOT_LAST_STATUS_MV
refresh complete on demand
  as
    SELECT 
    MAX(ID) LAST_STATUS, 
    COUNT(*) STATUS_COUNT, 
    ENTITY_ID 
FROM 
    D_LOT_STATUS_HISTORY 
GROUP BY 
    ENTITY_ID
/

