create trigger TRG_LOT_ENTITY_B_I
  before insert
  on D_LOT_ENTITY
  for each row
  begin
  if :new.IS_MEDINFO_TRANSFER_NOT_REQ is null then
    :new.IS_MEDINFO_TRANSFER_NOT_REQ := 0;
  end if; 
end;
/

