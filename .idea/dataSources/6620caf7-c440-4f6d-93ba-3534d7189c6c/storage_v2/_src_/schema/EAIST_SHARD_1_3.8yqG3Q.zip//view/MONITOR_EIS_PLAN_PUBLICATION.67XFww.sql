create view MONITOR_EIS_PLAN_PUBLICATION as
  SELECT allTbl.id,
                       grbs.id grbsId,
                       grbs.short_name grbsName,
                       allTbl.customer_id,
                       customer.short_name,
                       allTbl.plan_year,
                       allTbl.plan_type,
                       allTbl.IS_PUBLICATION_EXIST,
                       allTbl.STATUS_NAME,
                       allTbl.plan_version,
                       allTbl.EIS_VERSION,
                       allTbl.NPID,
                       allTbl.EIS_URL
                  FROM (SELECT DECODE (t1.id, NULL, t3.id, t1.id) id,
                               DECODE (t1.customer_id, NULL, t3.customer_id, t1.customer_id)
                                  customer_id,
                               DECODE (t1.year, NULL, t3.year, t1.year) plan_year,
                               'План закупок' PLAN_TYPE,
                               DECODE (TRUNC (NVL (t2.statusid, 100) / 100),
                                       0, 'ДА',
                                       1, 'НЕТ')
                                  IS_PUBLICATION_EXIST,
                               DECODE (t2.statusid,
                                       0, 'На согласовании ДФ',
                                       1, 'На согласовании ГРБС',
                                       2, 'Согласовано',
                                       3, 'К корректировке',
                                       4, 'Утверждён',
                                       5, 'Отправлен на публикацию',
                                       6, 'Ошибка публикации',
                                       7, 'Опубликован',
                                       8, 'Удалён',
                                       9, 'На согласовании ФО',
                                       10, 'Ожидание связки',
                                       11, 'Формирование',
                                       NULL, '',
                                       'Ошибка публикации')
                                  STATUS_NAME,
                               t1.plan_version,
                               t3.version EIS_VERSION,
                               t2.id NPID,
                               t3.OOS_URL EIS_URL
                          FROM (SELECT dpse.id,
                                       dpse.year,
                                       dpse.customer_id,
                                       dpsre.oos_version_223 plan_version,
                                       7 statusid
                                  FROM EAIST_SHARD_1_3.D_PLAN_SCHEDULE_ENTITY dpse
                                       LEFT JOIN
                                       EAIST_SHARD_1_3.d_plan_schedule_root_entity dpsre
                                          ON     dpsre.customer_id = dpse.customer_id
                                             AND dpsre.year = dpse.year
                                 WHERE dpse.year>2016 AND dpse.is223 = 1 and dpse.id IN (SELECT MAX (
                                                             dpse.id)
                                                          OVER (
                                                             PARTITION BY year, customer_id)
                                                             AS max_id
                                                     FROM EAIST_SHARD_1_3.D_PLAN_SCHEDULE_ENTITY dpse
                                                          JOIN
                                                          EAIST_SHARD_1_3.D_PLAN_SCHEDULE_VERSION dpsv
                                                             ON     dpsv.status_id = 7
                                                                AND dpsv.deleted_date IS NULL
                                                                AND dpsv.entity_id = dpse.id
                                                                AND dpse.is223 = 1)) t1
                               FULL OUTER JOIN
                               (SELECT id,
                                       year,
                                       customer_id,
                                       plan_version,
                                       statusid
                                  FROM (SELECT tb1.id,
                                               tb1.year,
                                               tb1.customer_id,
                                               tb1.plan_version,
                                               tb2.status_id statusid
                                          FROM EAIST_SHARD_1_3.D_PLAN_SCHEDULE_ENTITY tb1
                                               JOIN
                                               EAIST_SHARD_1_3.D_PLAN_SCHEDULE_VERSION tb2
                                                  ON     tb1.id = tb2.entity_id
                                                     AND tb2.deleted_date IS NULL and year>2016 and tb1.is223 = 1)
                                 WHERE year>2016 and id IN (SELECT MAX (dpse.id)
                                                        OVER (PARTITION BY year, customer_id)
                                                        AS max_id
                                                FROM EAIST_SHARD_1_3.D_PLAN_SCHEDULE_ENTITY dpse
                                                     JOIN
                                                     EAIST_SHARD_1_3.D_PLAN_SCHEDULE_VERSION dpsv
                                                        ON     dpsv.entity_id = dpse.id
                                                           AND dpsv.status_id != 7
                                                           AND dpsv.deleted_date IS NULL
                                                           AND dpsv.status_id != 8
                                                           AND dpse.is223 = 1)) t2
                                  ON t1.year = t2.year AND t1.customer_id = t2.customer_id
                               FULL OUTER JOIN
                               (SELECT tbl2.*, tbl1.id, tbl1.oos_url
                                  FROM (SELECT DISTINCT
                                               MAX (
                                                  version)
                                               OVER (
                                                  PARTITION BY TO_CHAR (start_date, 'yyyy'),
                                                               customer_id)
                                                  AS version,
                                               customer_id,
                                               TO_CHAR (start_date, 'yyyy') year
                                          FROM EAIST_SHARD_1_3.D_OOS_FTP_PURCHASEPLAN
                                         WHERE PLAN_TYPE = 'COMMODITY') tbl2
                                       JOIN (SELECT id,
                                                    version,
                                                    customer_id,
                                                    TO_CHAR (start_date, 'yyyy') year,
                                                    oos_url
                                               FROM EAIST_SHARD_1_3.D_OOS_FTP_PURCHASEPLAN
                                              WHERE PLAN_TYPE = 'COMMODITY') tbl1
                                          ON     tbl2.version = tbl1.version
                                             AND tbl2.customer_id = tbl1.customer_id
                                             AND tbl2.year = tbl1.year) t3
                                  ON t1.customer_id = t3.customer_id AND t3.year = t1.year)
                       allTbl
                       LEFT JOIN EAIST_NSI.N_PARTICIPANT customer
                          ON customer.id = allTbl.customer_id
                       JOIN EAIST_NSI.N_PARTICIPANT grbs ON customer.parent_grbs = grbs.id
/

