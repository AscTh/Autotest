create view PURCHASE_POSITION as
  SELECT DISTINCT
  pe.ID AS "PE_ID",
  pv.ID AS "PV_ID",
  pe.IKZ,
  pv.PLANNED_PUBLISH_YEAR,
  o.code,
  o.name,
  pv.KVR,
  pv.PGZ_REASON,
  pv.IS_DURATION_SELECTED,
  pv.DURATION_PURCHASE_DATE,
  pv.COUNT_REPEAT_PERIODICITY,
  pv.PERIODICITY_START_DATE,
  pv.CANCELED_PURCHASE_IS_PUBLISHED,
  pv.STATUS_ID,
  dppe.PERIOD
FROM
  D_PURCHASE_ENTITY pe
  LEFT JOIN D_PURCHASE_VERSION pv ON (pe.ID = pv.ENTITY_ID AND pv.DELETED_DATE IS NULL)
  LEFT JOIN d_purchase_plan_purchase_entry dpppe ON pv.ID = dpppe.PURCHASE_ID
  LEFT JOIN d_purchase_plan_version dppv ON dpppe.PURCHASE_PLAN_ID = dppv.ID
  LEFT JOIN d_purchase_plan_entity dppe ON dppv.ENTITY_ID = dppe.ID
  LEFT JOIN eaist_nsi.n_kpgz k ON (pv.kpgz_id = k.id)
  LEFT JOIN eaist_nsi.n_okpd_2 o ON (k.OKPD2_ID = o.id)
/

