create view POSITIONS_CANC_PLAN_PURCHASE as
  SELECT
    pe.ID AS              "PURCHASE_ENTITY_ID",
    pe.CUSTOMER_ID,
    pv.PLANNED_PUBLISH_YEAR "YEAR",
    pe.ikz,
    pv.pgz_reason,
    o.code,
    o.name,
    sum(ple.purchase_sum) purchase_sum,
    pv.public_discution,
    pv.canceled_purchase_is_published
  FROM
    d_purchase_entity pe
    JOIN d_purchase_version pv
      ON pv.ENTITY_ID = pe.ID AND pv.STATUS_ID = 7 AND pv.CANCELED_PURCHASE_IS_PUBLISHED = 1 AND pv.DELETED_DATE IS NULL
    JOIN eaist_nsi.n_kpgz k ON pv.kpgz_id = k.id
    JOIN eaist_nsi.n_okpd_2 o ON k.OKPD2_ID = o.id
    JOIN d_purchase_limit_entry ple ON pv.id = ple.purchase_id
  WHERE
    pe.WAS_PUBLISHED = 1
  GROUP BY pe.YEAR, pe.IKZ, pv.PGZ_REASON, o.code, o.name, pv.public_discution, pv.canceled_purchase_is_published,
    pe.CUSTOMER_ID, pe.ID, pv.PLANNED_PUBLISH_YEAR
/

