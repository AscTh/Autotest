create materialized view MV_PURCHASE_SUMREST
refresh force on demand
  as
    select lim.psum - NVL(doz.dpsum, 0) PURCHASESUMREST, lim.PURCHASE_ID from
                        (select sum(purchase_sum) psum, ple.PURCHASE_ID
                        from D_PURCHASE_LIMIT_ENTRY ple group by ple.PURCHASE_ID) lim
                        left join
                        (select sum(dpa.PURCHASE_SUM) dpsum, pdpe.PURCHASE_ID
                        from d_purchase_dpurchase_entry pdpe
                        join d_detailed_purchase_version dpv on dpv.id=pdpe.detailed_purchase_id and dpv.DELETED_DATE is null
                        join D_DETAILED_PURCHASE_AMOUNT dpa on dpa.dpurchase_id=dpv.id
                        join D_DPURCHASE_STATUS_HISTORY dpsh on dpv.ID = dpsh.VERSION_ID
                        where pdpe.IS_ACTUAL=1 and dpsh.id = (select max(dpsh2.id) from D_DPURCHASE_STATUS_HISTORY dpsh2 where
                        dpsh2.VERSION_ID = dpsh.VERSION_ID)
                        and not dpsh.status_id in (7, 8, 10)
                        group by pdpe.PURCHASE_ID) doz on doz.PURCHASE_ID = lim.PURCHASE_ID
/

