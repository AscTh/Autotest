create FUNCTION GET_LOT_NMC(lotId IN NUMBER) RETURN NUMBER
IS
  l_lotNmc NUMBER;
  l_lotId INT;
BEGIN
  IF lotId IS NULL THEN
    RETURN 0;
  END IF;

  SELECT contract_nmc, id
    INTO l_lotNmc, l_lotId
  FROM
     (SELECT contract_nmc, id, row_number() over (order by CREATED_DATE desc) rw
     FROM D_LOT_VERSION lv
     Where lv.ENTITY_ID = lotId)
  WHERE rw = 1;

  IF l_lotNmc IS NOT NULL THEN
    RETURN l_lotNmc;
  END IF;

  SELECT /*+ index(dpa index3) */nvl(SUM(dpa.PURCHASE_SUM), 0) INTO l_lotNmc
    FROM D_LOT_DPURCHASE_ENTRY ldpe, D_DETAILED_PURCHASE_AMOUNT dpa
   WHERE ldpe.LOT_ID = l_lotId
     and ldpe.IS_ACTUAL = 1
     and ldpe.DETAILED_PURCHASE_ID = dpa.DPURCHASE_ID;

  RETURN l_lotNmc;
EXCEPTION
  WHEN others THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

