create view VPURCHASE_INDEX as
  select pe.id ID,
            pv.ID PURCHASE_ID,
            pe.REGISTRY_NUMBER as REGISTRYNUMBER,
            pe.CODE CODE,
            pe.YEAR,
            pe.WAS_PUBLISHED WASPUBLISHED,
            pv.DELETED_DATE as DELETEDDATE,
            pv.KPGZ_ID as KPGZID,
            LISTAGG(TO_CHAR(ple.LIMIT_CODE), ';') WITHIN GROUP(ORDER BY ple.ID) LIMITCODE,
            LISTAGG(TO_CHAR(ple.FINANCIAL_SOURCE_TYPE), ';') WITHIN GROUP(ORDER BY ple.ID) LIMITTYPE,
            LISTAGG(TO_CHAR(ple.LIMIT_YEAR), ';') WITHIN GROUP(ORDER BY ple.ID) LIMITYEAR,
            max(ple.LIMIT_YEAR) as maxLimitYear,
            min(ple.LIMIT_YEAR) as minLimitYear,
            sum(ple.PURCHASE_SUM) PURCHASESUM,
            pe.CUSTOMER_ID CUSTOMERID,
            pv.STATUS_ID STATUSID,
            pv.STATUS_INFO STATUSINFO,
            (case
            when pv.IS_DURATION_SELECTED = 1 and
            not pv.DURATION_PURCHASE_DATE is null then
            pv.DURATION_PURCHASE_DATE
            else
            pv.PERIODICITY_START_DATE
            end) as purchaseDateStart,
            pv.PERIODICITY_START_DATE purchaseDateEnd,
            sumrest.PURCHASESUMREST,
            p.PURCHASEPLANID,
            pv.PUBLIC_DISCUTION PUBLICDISCUSSION,
            pe.not_Edit NOTEDIT,
            pv.PGZ_REASON PGZREASON,
            (case when kpgz.CODE is null then '' else kpgz.CODE || ':' || kpgz.FULL_NAME end) as name,
            pv.SENT_TO_CORRECTION SENTTOCORRECTION,
            pv.checked_in_grbs CHECKEDINGRBS,
            pe.is223 IS223,
            pe.IKZ IKZ
            from D_PURCHASE_ENTITY pe
            JOIN D_PURCHASE_VERSION pv
            on pe.ID = pv.ENTITY_ID
            and pv.deleted_date is NULL
            left JOIN D_PURCHASE_LIMIT_ENTRY ple
            on pv.ID = ple.PURCHASE_ID
            left join VPURCHASE_SUMREST sumrest
            on sumrest.PURCHASE_ID = pv.ID
            left join VPURCHASEPLANID p
            on p.PURCHASE_ID = pv.ID
            left join EAIST_NSI.N_KPGZ kpgz
            on pv.KPGZ_ID = kpgz.ID
            group by pe.id,
            pv.ID,
            pe.REGISTRY_NUMBER,
            pe.CODE,
            pe.YEAR,
            pe.WAS_PUBLISHED,
            pv.DELETED_DATE,
            pv.KPGZ_ID,
            pe.CUSTOMER_ID,
            pv.STATUS_ID,
            pv.STATUS_INFO,
            pv.PERIODICITY_START_DATE,
            pv.DURATION_PURCHASE_DATE,
            pv.IS_DURATION_SELECTED,
            sumrest.PURCHASESUMREST,
            p.PURCHASEPLANID,
            pv.PUBLIC_DISCUTION,
            pe.not_Edit,
            pv.PGZ_REASON,
            kpgz.CODE,
            kpgz.FULL_NAME,
            pv.SENT_TO_CORRECTION,
            pv.checked_in_grbs,
            pe.IS223,
            pe.IKZ
/

