create procedure granit_queue_failover(i_selector varchar2, i_node_name varchar2)
as
  p_value varchar2(256);
  pragma autonomous_transaction;
begin
  select k.value into p_value from locking_keys k where k.key=i_selector||'.granit.queue.lock' for update;
  update queue_item qi
  set qi.locked=0, qi.node_name='ANY', qi.status=1, qi.error_count=0
  where qi.id in (
       select x.id
       from (
          select q.id
          from queue_item q
          where 1=1
          and q.node_name in (i_node_name)
          and q.status in (2,3)
          and q.queue=i_selector
       ) x
  );
  update locking_keys k set k.value=i_node_name where k.key=i_selector||'.granit.queue.lock';
  commit;
end;
/

