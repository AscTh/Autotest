create view PROTOCOL44_DENIED_PUBLISH_OOS as
  select pi.procedureid,
            pi.num,
            p.full_name,
            pi.amount,
            pi.methodofsupplier,
            (case
            when cs.session_type = 1 then
            'Протокол вскрытия конвертов с заявками на участие в открытом конкурсе'
            when cs.session_type = 2 then
            'Протокол рассмотрения и оценки заявок на участие в открытом конкурсе'
            when cs.session_type = 3 then
            'Протокол рассмотрения единственной заявки на участие'
            when cs.session_type = 4 then
            'Протокол предквалификационного отбора'
            when cs.session_type = 5 then
            'Протокол рассмотрения и оценки заявок на участие в конкурсе с ограниченным участием'
            when cs.session_type = 6 then
            'Протокол первого этапа двухэтапного конкурса'
            when cs.session_type = 7 then
            'Протокол рассмотрения заявок на участие в электронном аукционе'
            when cs.session_type = 8 then
            'Протокол рассмотрения единственной заявки на участие в электронном аукционе'
            when cs.session_type = 9 then
            'Протокол проведения электронного аукциона'
            when cs.session_type = 10 then
            'Протокол о признании электронного аукциона несостоявшимся'
            when cs.session_type = 11 then
            'Протокол подведения итогов электронного аукциона'
            when cs.session_type = 12 then
            'Протокол рассмотрения и оценки заявок на участие в запросе котировок'
            when cs.session_type = 13 then
            'Протокол рассмотрения заявок на участие в предварительном отборе'
            when cs.session_type = 14 then
            'Протокол проведения запроса предложений'
            when cs.session_type = 15 then
            'Итоговый протокол проведения запроса предложений'
            when cs.session_type = 0 then
            'Неопределён'
            when cs.session_type = 16 then
            'Протокол рассмотрения и оценки единственной заявки на участие в двухэтапом конкурсе'
            when cs.session_type = 17 then
            'Протокол рассмотрения и оценки заявок по результатам продления сроков подачи заявок на участие в запросе котировок'
            when cs.session_type = 18 then
            'Протокол вскрытия конвертов с заявками на участие в конкурсе с ограниченным участием'
            when cs.session_type = 19 then
            'Протокол рассмотрения и оценки единственной заявки на участие в конкурсе с ограниченным участием'
            when cs.session_type = 20 then
            'Протокол предквалификационного отбора двухэтапного конкурса'
            when cs.session_type = 21 then
            'Протокол вскрытия конвертов с заявками на участие в первом этапе двухэтапного конкурса'
            when cs.session_type = 22 then
            'Протокол вскрытия конвертов с заявками на участие во втором этапе двухэтапного конкурса'
            when cs.session_type = 23 then
            'Протокол рассмотрения и оценки заявок на участие в двухэтапом конкурсе'
            when cs.session_type = 24 then
            'Протокол рассмотрения заявки единственного участника электронного аукциона'
            end) as cs_type,
            o.object_id,
            o.errors
            from d_commission_session cs
            join d_procedure_entity_index pi
            on cs.procedure_id = pi.procedureid
            join n_participant p
            on p.entity_id = pi.customerid
            and p.deleted_date is null
            join (
            with qur as
            (select object_id, xmltype(xml_from_oos, 0) xm from d_oos_exchange_protocol oep
            where object_type in ('EF', 'EP', 'OKD', 'OKOU', 'OK', 'PO', 'ZK', 'ZP')
            and receive_from_oos_date is not null and id = (select max(id) from d_oos_exchange_protocol where object_id = oep.object_id)
            )
            select object_id, name || ': ' || description as errors from qur,
            xmltable(xmlnamespaces(default 'http://zakupki.gov.ru/oos/integration/1', 'http://zakupki.gov.ru/oos/types/1' as "ns2"),
            'confirmation/data' passing xm columns xml_field xmltype path 'ns2:violations') p,
            xmltable(xmlnamespaces(default 'http://zakupki.gov.ru/oos/integration/1', 'http://zakupki.gov.ru/oos/types/1' as "ns2"),
            'ns2:violations/ns2:violation' passing p.xml_field columns
            name varchar2(4000) path 'ns2:name',
            description varchar2(4000) path 'ns2:description')
            ) o
            on o.object_id = cs.id
/

