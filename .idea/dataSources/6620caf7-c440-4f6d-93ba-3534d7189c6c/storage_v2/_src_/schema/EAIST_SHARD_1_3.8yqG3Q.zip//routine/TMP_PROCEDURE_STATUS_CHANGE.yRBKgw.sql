create function TMP_procedure_status_change(in_entity_id in number, id_status_id in number) return number
                is
                v_errNumber number:=0;
                v_errMessage varchar2(4000);
                pv_count number;
                pi_count number;
                ph_count number;
                status_name varchar2(100 char);
                begin
                case in_entity_id
                when 10 then status_name:='Согласована ГРБС';
                when 16 then status_name:='Пройдена экпертиза НМЦ';
                when 7 then status_name:='Извещение опубликовано';
                when 28 then status_name:='На публикации';
                when 18 then status_name:='Торги завершены';
                when 19 then status_name:='Ожидает публикации';
                else status_name:='';
                end case;

                if status_name='' then return 0;
                else
                update d_procedure_version pv
                set pv.status_id = id_status_id
                where pv.entity_id = in_entity_id
                and pv.deleted_date is null;
                pv_count:=sql%rowcount;

                update d_procedure_entity_index pi
                set pi.statusid = id_status_id, pi.statusname = status_name
                where pi.procedureid = in_entity_id;
                pi_count:=sql%rowcount;

                insert into d_procedure_status_history (id,
                                                        entity_id,
                                                        status_id,
                                                        user_id,
                                                        status_date,
                                                        comment_,
                                                        version_id)
                values
                (seq_procedurestatushistory.nextval,
                in_entity_id,
                id_status_id,
                3,
                sysdate,
                null,
                status_name);
                ph_count:=sql%rowcount;

                if pv_count=1 and pi_count=1 and ph_count=1
                then commit;
                dbms_output.put_line('Procedure entity_id='||in_entity_id||' changed status successfully');
                return 1;
                else rollback;
                dbms_output.put_line('ERROR change status - not found procedure entity_id='||in_entity_id);
                return 0;
                end if;
                end if;

                exception when others
                then rollback;
                v_errNumber := SQLCODE;
                v_errMessage := SQLERRM;
                dbms_output.put_line(SQLCODE||' '||SQLERRM);
                return 0;
                end;
/

