create view VPURCHASEPLANID as
  SELECT '#' || LISTAGG(TO_CHAR(ppv.ENTITY_ID), '##') WITHIN GROUP (ORDER BY ppv.ENTITY_ID) || '#' PURCHASEPLANID,
            pppe.purchase_ID PURCHASE_ID
            FROM D_PURCHASE_PLAN_PURCHASE_ENTRY pppe
            JOIN D_PURCHASE_PLAN_VERSION ppv ON pppe.PURCHASE_PLAN_ID = ppv.ID
            where pppe.is_actual = 1
            group by pppe.purchase_ID
/

