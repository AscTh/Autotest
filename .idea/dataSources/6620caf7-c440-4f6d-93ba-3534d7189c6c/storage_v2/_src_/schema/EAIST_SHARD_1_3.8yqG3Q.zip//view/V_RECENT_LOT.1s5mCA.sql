create view V_RECENT_LOT as
  SELECT

  le.id as entity_id,

  lv.id,

  le.year,

  roots.root_count,

  children.children_count,

  le.customer_id,

  le.REGISTRY_NUMBER,

  lsh.STATUS_ID as entity_status_id,
  
  lv.STATUS_ID as status_id,

  lv.METHOD_OF_SUPPLIER_ID,

  lv.contract_nmc,

  dpss.DPURCHASE_SUM,

  lv.START_DATE,

  lv.LOT_NAME

FROM D_LOT_ENTITY le

  JOIN D_LOT_STATUS_HISTORY lsh ON le.ID = lsh.ENTITY_ID AND lsh.ID = (SELECT MAX(ID)

                                                                       FROM D_LOT_STATUS_HISTORY

                                                                       WHERE ENTITY_ID = le.ID)

  JOIN D_LOT_VERSION lv ON le.ID = lv.ENTITY_ID AND lv.ID = (SELECT MAX(ID)

                                                             FROM D_LOT_VERSION

                                                             WHERE ENTITY_ID = le.ID AND deleted_date IS NULL)

  JOIN (

         SELECT

           SUM(DPS.PURCHASE_SUM) AS DPURCHASE_SUM,

           lpe.lot_id

         FROM D_DETAILED_PURCHASE_SPEC DPS

           JOIN D_LOT_DPURCHASE_ENTRY lpe ON lpe.DETAILED_PURCHASE_ID = DPS.DPURCHASE_ID

         WHERE lpe.is_actual = 1

         GROUP BY lpe.lot_id

       ) DPSS ON lv.ID = DPSS.LOT_ID

  LEFT OUTER JOIN (SELECT

                     count(*) AS children_count,

                     ROOT_LOT_ID

                   FROM D_LOT_LOT_ENTRY

                   WHERE IS_ACTUAL = 1

                   GROUP BY ROOT_LOT_ID) children ON children.root_lot_id = lv.id

  LEFT OUTER JOIN (SELECT

                     count(*) AS root_count,

                     LOT_ID

                   FROM D_LOT_LOT_ENTRY

                   WHERE IS_ACTUAL = 1

                   GROUP BY LOT_ID) roots ON roots.lot_id = lv.id
/

