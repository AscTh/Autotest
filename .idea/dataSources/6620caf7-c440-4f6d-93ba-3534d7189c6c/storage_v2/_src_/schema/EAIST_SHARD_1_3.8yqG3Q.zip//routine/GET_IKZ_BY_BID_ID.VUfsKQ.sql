create FUNCTION                 get_ikz_by_bid_id (
                bid_id IN INTEGER
            ) RETURN VARCHAR2 IS
                res_ikz   VARCHAR2(4000);
            BEGIN
                SELECT
                    CASE
                        WHEN lv.joint_auction = 1 THEN N'совместная закупка'
                        WHEN pe.ikz IS NOT NULL THEN pe.ikz
                        WHEN le.ikz IS NOT NULL THEN le.ikz
                        ELSE N'отсутствует'
                    END
                INTO
                    res_ikz
                FROM
                    d_mrg_bid b
                    JOIN d_mrg_bid_lot bl ON ( bl.mrg_bid_id = b.id )
                    JOIN d_lot_entity le ON ( le.id = b.lot_id )
                    LEFT JOIN d_lot_dpurchase_entry ldpe ON ( ldpe.lot_id = bl.lot_version_id )
                    LEFT JOIN d_lot_version lv ON ( lv.id = bl.lot_version_id )
                    LEFT JOIN d_detailed_purchase_version dpv ON ( dpv.id = ldpe.detailed_purchase_id )
                    LEFT JOIN d_purchase_dpurchase_entry pdpe ON ( pdpe.detailed_purchase_id = dpv.id
                                                                   AND pdpe.is_actual = 1 )
                    LEFT JOIN d_purchase_version pv ON ( pv.id = pdpe.purchase_id )
                    LEFT JOIN d_purchase_entity pe ON ( pe.id = pv.entity_id )
                WHERE
                    b.id = bid_id;

                RETURN res_ikz;
            EXCEPTION
                WHEN OTHERS THEN
                    RETURN N'отсутствует';
            END get_ikz_by_bid_id;
/

