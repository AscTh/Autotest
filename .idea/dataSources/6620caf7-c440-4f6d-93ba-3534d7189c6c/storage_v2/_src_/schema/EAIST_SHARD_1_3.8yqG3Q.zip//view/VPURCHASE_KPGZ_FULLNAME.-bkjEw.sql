create view VPURCHASE_KPGZ_FULLNAME as
  select pv.id PURCHASE_ID, t.full_name from D_PURCHASE_VERSION pv
            join
            (select
            connect_by_root k.ID ID,
            ltrim(replace(reverse(sys_connect_by_path(reverse(' ' || k.name),'|')), '|', '\')) as full_name
            from EAIST_NSI.N_KPGZ k
            where k.PARENT_ID is null
            connect by prior k.parent_id = k.id) t on t.ID = pv.KPGZ_ID
/

