create function bytesToNameUuid (bytes in RAW) return varchar2
            AS LANGUAGE JAVA NAME 'UuidUtils.bytesToNameUuid(byte[]) return java.lang.String';
/

