create FUNCTION GET_IDS(len number) RETURN NUMBER IS
           START_ID NUMBER(15);
          BEGIN
           SELECT max(seq_count) INTO START_ID FROM sequence WHERE seq_name='SEQ_GEN';
           update sequence set seq_count = seq_count + len;
           RETURN START_ID;
          END;
/

