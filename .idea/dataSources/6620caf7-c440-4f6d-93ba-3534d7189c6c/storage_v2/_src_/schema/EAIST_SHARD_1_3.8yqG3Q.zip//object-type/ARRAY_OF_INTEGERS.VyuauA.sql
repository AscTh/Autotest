create TYPE                   "ARRAY_OF_INTEGERS"                                          AS TABLE OF integer
/

