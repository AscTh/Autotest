create trigger D_PLAN_SCHEDULE_OOS_MIGR_BI
  before insert
  on D_PLAN_SCHEDULE_OOS_MIGRATION
  for each row
  BEGIN
  SELECT seq_d_plan_schedule_oos_migr.NEXTVAL
    INTO :new.id
    FROM dual;
END;
/

