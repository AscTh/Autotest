create FUNCTION                 F_GET_NMC_BY_LOT_VERSION(p_id IN NUMBER)
                RETURN NUMBER
                IS
                  l_lot_nmc NUMBER;
                BEGIN
                  if p_id is null then
                    raise_application_error(-20000, 'p_id can not be null');
                  end if;

                  with temp as (
                    select /*+ index(dlde INDEX8) */
                      ddpv.id as doz_version_id,
                      (   select count(*)
                          from d_purchase_dpurchase_entry i_dpde
                              join d_purchase_version i_dpv on i_dpv.id = i_dpde.purchase_id
                          where i_dpde.detailed_purchase_id = ddpv.id
                              and i_dpv.small_volume != 0 and i_dpde.is_actual = 1 and rownum < 2
                      ) not_zero_oz_count
                    from
                      d_lot_dpurchase_entry dlde
                      join d_detailed_purchase_version ddpv on dlde.detailed_purchase_id = ddpv.id
                    where
                      dlde.lot_id in (
                        select p_id from dual
                        union all
                        select lot_id
                        from d_lot_lot_entry dlle
                        where dlle.root_lot_id = p_id
                            and dlle.is_actual = 1
                      ) and dlde.is_actual = 1
                  ),
                  summs as (
                    select
                      case
                        when not_zero_oz_count != 0 then
                          (select sum(purchase_sum) from d_detailed_purchase_amount ddps
                          where ddps.dpurchase_id = doz_version_id)
                        else
                          (select sum(purchase_sum) from d_detailed_purchase_spec ddps
                          where ddps.dpurchase_id = doz_version_id)
                      end purchase_sum
                    from temp
                  )
                  select sum(purchase_sum)
                  into l_lot_nmc
                  from summs;

                  RETURN l_lot_nmc;
                END;
/

