create function guidToBytes (guid in varchar2) return RAW
            AS LANGUAGE JAVA NAME 'UuidUtils.guidToBytes(java.lang.String) return byte[]';
/

