create function bytesToGuid (bytes in RAW) return varchar2
            AS LANGUAGE JAVA NAME 'UuidUtils.bytesToGuid(byte[]) return java.lang.String';
/

