create function bytesToNameUuidBytes (bytes in RAW) return RAW
            AS LANGUAGE JAVA NAME 'UuidUtils.bytesToNameUuidBytes(byte[]) return byte[]';
/

