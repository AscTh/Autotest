create PROCEDURE PROCEDURE_STATUS_CHANGE(in_entity_id IN NUMBER, in_status_id IN NUMBER, out_success OUT NUMBER) AS
            v_errNumber number := 0;
            v_errMessage VARCHAR2(4000);
            pv_count NUMBER;
            pi_count NUMBER;
            ph_count NUMBER;
            status_name VARCHAR2(100 CHAR);
            proc_version_id NUMBER;
            mrg_bid_id NUMBER;

            BEGIN
                CASE in_status_id
                    WHEN 10 THEN status_name := 'Согласована ГРБС';
                    WHEN 16 THEN status_name := 'Пройдена экпертиза НМЦ';
                    WHEN 7  THEN status_name := 'Извещение опубликовано';
                    WHEN 28 THEN status_name := 'На публикации';
                    WHEN 18 THEN status_name := 'Торги завершены';
                    WHEN 19 THEN status_name := 'Ожидает публикации';
                    WHEN 1  THEN status_name := 'Формирование';
                    WHEN 15 THEN status_name := 'Отправлена на экспертизу НМЦ';
                    WHEN 44 THEN status_name := 'Согласована МРГ';
                    ELSE         status_name := null;
                END CASE;

                IF status_name IS NOT null THEN
                    UPDATE d_procedure_version pv
                    SET pv.status_id = in_status_id
                    WHERE pv.entity_id = in_entity_id AND pv.deleted_date is null;

                    pv_count := sql%rowcount;

                    UPDATE d_procedure_entity_index pi
                    SET pi.statusid = in_status_id, pi.statusname = status_name
                    WHERE pi.procedureid = in_entity_id;

                    pi_count := sql%rowcount;

                    INSERT INTO d_procedure_status_history ph (
                        id,
                        entity_id,
                        status_id,
                        user_id,
                        status_date,
                        comment_,
                        version_id
                    ) VALUES (
                        seq_procedurestatushistory.nextval,
                        in_entity_id,
                        in_status_id,
                        3,
                        sysdate,
                        status_name,
                        0
                    );

                    ph_count := sql%rowcount;

                    if (in_status_id = 44) then
                        begin
                            select id into proc_version_id from d_procedure_version where entity_id = in_entity_id and deleted_date is null;
                            exception when no_data_found then null;
                        end;
                        if (proc_version_id is not null) then
                            update d_procedure_entity set is_rg_mrg_passed = 1 where id = in_entity_id;
                            begin
                                select id into mrg_bid_id from d_mrg_bid where procedure_version_id = proc_version_id;
                                exception when no_data_found then null;
                            end;
                            if (mrg_bid_id is not null) then
                                update d_mrg_bid set status_id = 18, agenda_id = null, mrg_agenda_id = null where procedure_version_id = proc_version_id;
                                insert into d_mrg_bid_history (id, creation_date, bid_id, user_id, status_id)
                                values (seq_mrg_bid_history.nextval, systimestamp, mrg_bid_id, 3, 18);
                            end if;
                        end if;
                    end if;

                    IF pv_count = 1 AND pi_count = 1 AND ph_count = 1 THEN
                        out_success := 1;
                    ELSE
                        out_success := 0;
                    END IF;
                END IF;
            END;
/

