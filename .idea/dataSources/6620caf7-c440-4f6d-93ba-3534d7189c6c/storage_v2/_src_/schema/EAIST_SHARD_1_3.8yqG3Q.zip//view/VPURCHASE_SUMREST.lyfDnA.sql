create view VPURCHASE_SUMREST as
  select /*+ dynamic_sampling(0) */ lim.psum - NVL(doz.dpsum, 0) PURCHASESUMREST, lim.PURCHASE_ID from
                    (select /*+ dynamic_sampling(0) */ sum(purchase_sum) psum, ple.PURCHASE_ID
                    from D_PURCHASE_LIMIT_ENTRY ple group by ple.PURCHASE_ID) lim
                    left join
                    (select /*+ dynamic_sampling(0) */ sum(dpa.PURCHASE_SUM) dpsum, pdpe.PURCHASE_ID
                    from D_PURCHASE_DPURCHASE_ENTRY pdpe
                    join D_DETAILED_PURCHASE_VERSION dpv on dpv.id=pdpe.detailed_purchase_id and dpv.DELETED_DATE is null
                    join D_DETAILED_PURCHASE_AMOUNT dpa on dpa.dpurchase_id=dpv.id
                    where pdpe.IS_ACTUAL=1 and not dpv.status_id in (7, 8, 10)
                    group by pdpe.PURCHASE_ID) doz on doz.PURCHASE_ID = lim.PURCHASE_ID
/

