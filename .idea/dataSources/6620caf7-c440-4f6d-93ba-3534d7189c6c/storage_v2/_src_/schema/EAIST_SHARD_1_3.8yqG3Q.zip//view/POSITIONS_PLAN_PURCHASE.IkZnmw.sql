create view POSITIONS_PLAN_PURCHASE as
  SELECT
    ppe.ID AS             "PLAN_ID",
    pe.ID  AS             "PURCHASE_ENTITY_ID",
    pe.YEAR,
    pe.ikz,
    pv.pgz_reason,
    pv.ENTITY_ID,
    pv.STATUS_ID,
    o.code,
    o.name,
    sum(ple.purchase_sum) purchase_sum,
    pv.public_discution,
    pv.canceled_purchase_is_published,
    pppe.PURCHASE_ID
  FROM
    D_PURCHASE_PLAN_ENTITY ppe
    JOIN d_purchase_plan_version ppv ON ppe.ID = ppv.ENTITY_ID
    JOIN d_purchase_plan_purchase_entry pppe ON ppv.id = pppe.purchase_plan_id AND pppe.is_actual = 1
    JOIN d_purchase_version pv ON pppe.purchase_id = pv.id AND pv.deleted_date IS NULL
    JOIN d_purchase_entity pe ON pv.entity_id = pe.id
    LEFT JOIN eaist_nsi.n_kpgz k ON pv.kpgz_id = k.id
    LEFT JOIN eaist_nsi.n_okpd_2 o ON k.OKPD2_ID = o.id
    LEFT JOIN d_purchase_limit_entry ple ON pv.id = ple.purchase_id
  WHERE
    ppv.DELETED_DATE IS NULL
  GROUP BY pe.YEAR, pe.IKZ, pv.PGZ_REASON, o.code, o.name, pv.public_discution, pv.canceled_purchase_is_published,
    ppe.ID, pe.ID, pppe.PURCHASE_ID, pv.STATUS_ID, pv.ENTITY_ID
/

