create procedure granit_queue_enable(i_selector varchar2, i_really varchar2)
as
  pragma autonomous_transaction;
begin
  update LOCKING_KEYS set value=i_really where key=i_selector||'.granit.queue.enabled';
  commit;
end;
/

