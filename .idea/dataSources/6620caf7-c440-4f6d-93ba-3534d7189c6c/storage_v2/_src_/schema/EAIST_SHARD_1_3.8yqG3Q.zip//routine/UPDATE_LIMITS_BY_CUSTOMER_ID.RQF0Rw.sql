create procedure                 UPDATE_LIMITS_BY_CUSTOMER_ID(p_customer in number) is
            p_year number;
            cursor c1(n_year number) is select year from eaist_shard_1_3.d_limit_project where customer_id = p_customer and FINANCIAL_SOURCE_TYPE = 'OWN_FUNDS' and year = n_year;
            cursor c2(n_year number) is select year from eaist_shard_1_3.d_limit_project where customer_id = p_customer and FINANCIAL_SOURCE_TYPE = 'OWN_FUNDS_SUB' and year = n_year;
            cursor c3(n_year number) is select year from eaist_shard_1_3.d_limit_project_agreemnt_state where customer_id = p_customer and year = n_year;
            cursor c4(n_year number) is select year from eaist_nsi.n_financial_limit where customer_id = p_customer and FINANCIAL_SOURCE_TYPE = 'OWN_FUNDS' and year = n_year;
            cursor c5(n_year number) is select year from eaist_nsi.n_financial_limit where customer_id = p_customer and FINANCIAL_SOURCE_TYPE = 'OWN_FUNDS_SUB' and year = n_year;

            BEGIN
                for i in 2018..2060 loop
                    OPEN c1(i);
                    FETCH c1 INTO p_year;
                    if c1%notfound then
                    insert into eaist_shard_1_3.d_limit_project values (eaist_shard_1_3.seq_limitproject.nextval, 'OWN_FUNDS', p_customer, i, 0);
                    end if;
                    close c1;

                    OPEN c2(i);
                    FETCH c2 INTO p_year;
                    if c2%notfound then
                    insert into eaist_shard_1_3.d_limit_project values (eaist_shard_1_3.seq_limitproject.nextval, 'OWN_FUNDS_SUB', p_customer, i, 0);
                    end if;
                    close c2;

                    OPEN c3(i);
                    FETCH c3 INTO p_year;
                    if c3%notfound then
                    insert into eaist_shard_1_3.d_limit_project_agreemnt_state values (eaist_shard_1_3.seq_limitprojectagrmntstate.nextval, 1, p_customer, i);
                    end if;
                    close c3;

                    OPEN c4(i);
                    FETCH c4 INTO p_year;
                    if c4%notfound then
                    insert into eaist_nsi.n_financial_limit f values (eaist_nsi.seq_limit.nextval, sysdate, null, null, i,'-', 0, 0,
                    p_customer, null, null, null, null, null, null, '-', 'OWN_FUNDS', 0, 0, 0, null, null, null, 0, null, 0, 1, 0,null);
                    end if;
                    close c4;

                    OPEN c5(i);
                    FETCH c5 INTO p_year;
                    if c5%notfound then
                    insert into eaist_nsi.n_financial_limit f values (eaist_nsi.seq_limit.nextval, sysdate, null, null, i,'-', 0, 0,
                    p_customer, null, null, null, null, null, null, '-', 'OWN_FUNDS_SUB', 0, 0, 0, null, null, null, 0, null, 0, 1,0,null);
                    end if;
                    close c5;
                end loop;

                commit;
            END;
/

