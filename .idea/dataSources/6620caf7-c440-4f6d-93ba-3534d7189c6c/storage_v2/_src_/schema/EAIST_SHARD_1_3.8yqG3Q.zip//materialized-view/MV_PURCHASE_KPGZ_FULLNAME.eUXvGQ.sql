create materialized view MV_PURCHASE_KPGZ_FULLNAME
refresh force on demand
  as
    select pv.id PURCHASE_ID, t.full_name from D_PURCHASE_VERSION pv
                            join
                            (select
                            connect_by_root k.ID ID,
                            ltrim(replace(reverse(sys_connect_by_path(reverse(' ' || k.name),'|')), '|', '\')) as full_name
                            from eaist_nsi.kpgz k
                            where k.PARENT_ID is null
                            connect by prior k.parent_id = k.id) t on t.ID = pv.KPGZ_ID
/

