create FUNCTION TRANSLATE_XSD_VALIDATION
            (
                xsd_message IN VARCHAR2
                , r_object_type_id IN NUMBER
                , r_object_id IN NUMBER
            ) RETURN VARCHAR2 IS

            result_message VARCHAR2(4000);
            message_tmp VARCHAR2(10000);
            TYPE idsList IS TABLE OF VARCHAR2(100);
            invalid_entities_ids idsList;

            BEGIN
                IF (xsd_message IS NULL OR r_object_type_id IS NULL OR r_object_id IS NULL) THEN
                    RETURN NULL;
                END IF;

                FOR rule_ IN (
                    SELECT rules_.regexp, rules_.invalid_entities_query, rules_.message_mask
                    FROM xsd_err_translation_rules rules_
                    WHERE rules_.root_object_type_id = r_object_type_id AND rules_.is_active = 1
                ) LOOP
                    IF (REGEXP_LIKE(xsd_message, rule_.regexp)) THEN
                        EXECUTE IMMEDIATE REPLACE(rule_.invalid_entities_query, '[root_entity_id]', r_object_id)
                        BULK COLLECT INTO invalid_entities_ids;
                        FOR i IN 1..invalid_entities_ids.COUNT LOOP
                            message_tmp := result_message || REPLACE(rule_.message_mask, '[entity_id]', invalid_entities_ids(i)) || CHR(10);
                            IF (length(message_tmp) <= 4000) THEN
                                result_message := message_tmp;
                            ELSE
                                RETURN RESULT_MESSAGE;
                            END IF;
                        END LOOP;
                    END IF;
                END LOOP;
                RETURN RESULT_MESSAGE;
            EXCEPTION
                WHEN OTHERS THEN
                    --DBMS_OUTPUT.PUT_LINE(SQLERRM);
                    return null;
            END TRANSLATE_XSD_VALIDATION;
/

