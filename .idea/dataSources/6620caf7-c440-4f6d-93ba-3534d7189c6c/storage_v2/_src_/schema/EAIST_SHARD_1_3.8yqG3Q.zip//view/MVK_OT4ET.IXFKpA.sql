create view MVK_OT4ET as
  select c.name, c.inn, lots.id lot_id,lots.registry_number lot_num,lots.STATUSVALUE lot_status,sch_version.publication_date,lots.doz_entity_id,lots.doz_num,kpgz.code doz_kpgz_code,spgz.name doz_spgz_name,proc_v.entity_id procedure_id,proc_v.created_date PROCEDURE_CREATED_DATE,proc_v.status_id PROCEDURE_STATUS,proc_v.purchase_date PROCEDURE_PURCHASE_DATE,lots.EAIST1_CONTRACT_REG_NUMBER CONTRACT_ID,contr.created_date CONTRACT_CREATED_DATE,state.name CONTRACT_STATE from eaist_rc.customer c 
left JOIN (select t1.id,t2.id lvid,t1.registry_number, t1.customer_id,T3.STATUSVALUE,t5.id doz_id,t5.entity_id doz_entity_id,t6.registry_number doz_num,T1.EAIST1_CONTRACT_REG_NUMBER
from d_lot_entity t1,d_lot_version t2,d_lot_index t3,d_lot_dpurchase_entry t4,D_DETAILED_PURCHASE_VERSION t5, D_DETAILED_PURCHASE_ENTITY t6 
where t2.supplier_id in (7282641,7249442,7150734,4612763) and t2.deleted_date is null and T1.ID = T2.ENTITY_ID and t3.id = t1.id and t4.lot_id = t2.id and T5.id = T4.detailed_purchase_id and t4.is_actual = 1 and t6.id = t5.entity_id and t4.detailed_purchase_id in
(select t0.id from D_DETAILED_PURCHASE_VERSION t0,D_PURCHASE_DPURCHASE_ENTRY t1, D_PURCHASE_LIMIT_ENTRY t2 where t2.limit_year = 2017 and t2.purchase_id = t1.purchase_Id and t1.is_actual =1 and t0.id = t1.DETAILED_PURCHASE_ID and t0.deleted_date is null)) lots
on lots.customer_id = c.id 
left join D_DETAILED_PURCHASE_SPEC doz_spec
on DOZ_SPEC.DPURCHASE_ID = lots.doz_id
left join EAIST_NSI.N_KPGZ kpgz
on kpgz.id = doz_spec.kpgz_id
left join EAIST_NSI.N_SPGZ spgz
on spgz.id = doz_spec.spgz_id
left join D_PROCEDURE_LOT_ENTRY proc
on proc.lot_id = lots.lvid and proc.is_actual =1
left join D_PROCEDURE_VERSION proc_v
on proc_v.id = proc.procedure_id and proc_v.deleted_date is null
left join EAIST_RC.CONTRACT contr
on contr.id = lots.EAIST1_CONTRACT_REG_NUMBER
left join EAIST_RC.STATE state
on state.id = contr.state_id
left join (select t2.*,t1.lot_id from D_PLAN_SCHEDULE_VERSION t2, D_PLAN_SCHEDULE_LOT_ENTRY t1 where t1.is_actual = 1 and t2.id=t1.plan_schedule_id and t2.publication_date is not null and t2.actual = 1) sch_version
on sch_version.lot_id = lots.lvid
where C.DELETED_DATE is null
/

