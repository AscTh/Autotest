create view V_PURCHASE_LIST as
  SELECT
    dpe.ID,
    dpe.REG_NUMBER,
    dpe.IS223,
    p.FULL_NAME,
    p.INN,
    p.SHORT_NAME,
    dpei.METHODOFSUPPLIER,
    dpei.METHODOFSUPPLIERID,
    dpei.STATUSID,
    dpei.AMOUNT,
    dpei.PROCUREMENTSUBJECT,
    dpd.PROCEDURE_DATE AS PUBLICATION_DATE,
    (SELECT MIN(PROCEDURE_DATE) FROM D_PROCEDURE_DATE WHERE PROCEDURE_ID = dpv.ID) AS UPDATED_DATE
FROM
    N_PARTICIPANT p
    JOIN D_PROCEDURE_ENTITY dpe
        ON dpe.CUSTOMER_ID = p.ID
    JOIN (
      select dpv.id, dpv.entity_id,
        row_number() over (partition by dpv.entity_id order by dpv.id desc) rn
      from D_PROCEDURE_VERSION dpv
      where dpv.deleted_date is null
    ) dpv ON dpv.ENTITY_ID = dpe.ID and dpv.rn = 1
    JOIN D_PROCEDURE_ENTITY_INDEX dpei
        ON dpe.ID = dpei.PROCEDUREID
    JOIN D_PROCEDURE_DATE dpd
        ON dpd.PROCEDURE_ID = dpv.ID AND dpd.DATE_TYPE = 'publicationDate'
WHERE
    (
        (
            (dpei.STATUSID = 7)
            OR (
                (dpei.STATUSID = 18)
                OR (dpei.STATUSID = 19)
            )
        )
    )
ORDER BY
    UPDATED_DATE DESC,
    dpe.ID DESC
/

