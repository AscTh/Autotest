create procedure granit_queue_portion(
          i_selector varchar2,
          i_node_name varchar2,
          i_portion_size in integer)
as
  p_value varchar2(256);
  pragma autonomous_transaction;
begin
  select k.value into p_value from locking_keys k where k.key=i_selector||'.granit.queue.lock' for update;
  --
  update queue_item qi
  set qi.locked=1, qi.node_name=i_node_name, qi.status=2,
    qi.error_count=(case when qi.error_count>=100 then 0 else qi.error_count end)
  where qi.id in (
    select x.id
      from (
        select q.*
        from (
          select q1.id, q1.queue_state_time
          from queue_item q1
          where 1=1
          and q1.node_name in ('ANY', i_node_name)
          and q1.status=1
          and q1.queue=i_selector
          and q1.queue_state_time<sysdate
          union
          select q2.id, q2.queue_state_time
          from queue_item q2
          where 1=1
          and q2.node_name in ('ANY', i_node_name)
          and q2.status=5
          and q2.queue=i_selector
          and q2.queue_state_time<sysdate-(nvl((
              select max(c.value) 
              from locking_keys c 
              where c.key=q2.queue||'.task.'||q2.queue_state||'.retry.sec'), 600)*q2.error_count/(24*60*60))
          and q2.error_count<nvl((
              select max(c.value)
              from locking_keys c 
              where c.key=q2.queue||'.task.'||q2.queue_state||'.retry.count'), 1)
        ) q
        order by q.queue_state_time asc
      ) x
    where rownum <= i_portion_size
  );
  update locking_keys k set k.value=i_node_name where k.key=i_selector||'.granit.queue.lock';
  commit;
end;
/

