create procedure GET_NMC_EXAM_NUMBER(contract_id in number, current_number out number) is
            begin
            update D_PARTICIPANT_CONTRACT_NMC
            set CURRENT_REQUEST_NUMBER = nvl(CURRENT_REQUEST_NUMBER, 0) + 1
            where id = contract_id
            returning CURRENT_REQUEST_NUMBER - 1 into current_number;
            end;
/

