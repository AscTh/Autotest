create view PLAN_SCHEDULE_LIST as
  SELECT
    t0.ID,
    t0.CUSTOMER_ID,
    t1.OOS_PLAN_NUMBER,
    t0.YEAR,
    t2.STATUS_ID,
    t2.ACTUAL,
    t2.PUBLICATION_DATE,
    t0.UPDATED_DT,
    t3.FULL_NAME,
    t3.inn,
    t3.kpp,
    t3.short_name
  FROM
    N_PARTICIPANT t3,
    D_PLAN_SCHEDULE_VERSION t2,
    D_PLAN_SCHEDULE_ROOT_ENTITY t1,
    D_PLAN_SCHEDULE_ENTITY t0
  WHERE
    (
      (
        (
          (
            (
              (
                (
                  t0.YEAR = t1.YEAR
                )
                AND (
                  t0.IS223 = 0
                )
                AND (
                  t0.CUSTOMER_ID = t1.CUSTOMER_ID
                )
              )
              AND (
                t3.ID = t0.CUSTOMER_ID
              )
            )
            AND (
              t0.ID = t2.ENTITY_ID
            )
          )
        )
        AND (
          (
            t2.STATUS_ID = 7
          )
          OR (
            t2.STATUS_ID = 5
          )
        )
      )
      AND (
        t2.DELETED_DATE IS NULL
      )
    )
  ORDER BY
    t0.UPDATED_DT DESC,
    t0.ID DESC
/

