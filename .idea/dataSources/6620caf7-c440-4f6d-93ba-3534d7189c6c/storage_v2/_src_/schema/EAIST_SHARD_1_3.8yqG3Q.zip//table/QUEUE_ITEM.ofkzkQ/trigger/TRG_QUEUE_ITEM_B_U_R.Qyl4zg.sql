create trigger TRG_QUEUE_ITEM_B_U_R
  before update
  on QUEUE_ITEM
  for each row
  begin
  if :new.node_name not like 'ne%' and :new.node_name not like 're%' and :new.node_name not like 'AN%' then
    :new.node_name := 'ANY';
    :new.status := 1;
  end if;
end;
/

