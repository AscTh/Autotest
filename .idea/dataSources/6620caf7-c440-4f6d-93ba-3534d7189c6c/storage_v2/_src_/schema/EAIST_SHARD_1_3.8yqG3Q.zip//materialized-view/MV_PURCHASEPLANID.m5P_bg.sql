create materialized view MV_PURCHASEPLANID
refresh force on demand
  as
    SELECT '#' || LISTAGG(TO_CHAR(ppv.ENTITY_ID), '##') WITHIN GROUP (ORDER BY ppv.ENTITY_ID) || '#' PURCHASEPLANID,
                        pv.ID PURCHASE_ID
                        FROM D_PURCHASE_VERSION pv
                        LEFT JOIN D_PURCHASE_PLAN_PURCHASE_ENTRY pppe ON pv.id=pppe.purchase_ID
                        LEFT JOIN D_PURCHASE_PLAN_VERSION ppv ON pppe.PURCHASE_PLAN_ID = ppv.ID
                        where  pppe.is_actual = 1
                        group by pv.ID
/

