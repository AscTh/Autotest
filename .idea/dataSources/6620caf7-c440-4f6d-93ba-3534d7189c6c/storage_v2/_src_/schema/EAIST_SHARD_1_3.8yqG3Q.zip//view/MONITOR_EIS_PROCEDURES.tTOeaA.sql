create view MONITOR_EIS_PROCEDURES as
  SELECT eaist_procedure_version_id,
                               d_oos_ftp_procedure_id,
                               grbs.id grbs_id,
                               grbs.short_name grbs_name,
                               customer.id customer_id,
                               customer.short_name,
                               reg_number,
                               eaist_publication_date,
                               eis_publication_date,
                               eaist_version,
                               eis_version,
                               eaist_pcn,
                               eis_pcn,
                               eaist_sum,
                               eis_sum
                          FROM (
                          SELECT   DECODE (tbl1.customer_id, NULL, tbl2.customer_id, tbl1.customer_id)
                                   customer_id,
                                   DECODE (tbl1.reg_number, NULL, tbl2.reg_number, tbl1.reg_number)
                                   reg_number,
                                   eaist_publication_date,
                                   eis_publication_date,
                                   eaist_version,
                                   eis_version,
                                   eis_pcn,
                                   methodofsupplier eaist_pcn,
                                   amount eaist_sum,
                                   eis_sum,
                                   eaist_procedure_version_id,
                                   d_oos_ftp_procedure_id
                          FROM (
                               SELECT
                                   dpv.id eaist_procedure_version_id,
                                   dpe.customer_id,
                                   dpe.reg_number,
                                   TO_CHAR (dpd.procedure_date, 'DD.MM.YYYY')
                                   eaist_publication_date,
                                   dpv.version eaist_version,
                                   dpei.methodofsupplier,
                                   dpei.amount
                               FROM (
                                       select max(tpe.id) id,tpe.customer_id,tpe.reg_number from EAIST_SHARD_1_3.D_PROCEDURE_ENTITY tpe where tpe.deleted_date IS NULL AND tpe.is223 = 1 group by tpe.customer_id,tpe.reg_number) dpe
                                                       JOIN EAIST_SHARD_1_3.D_PROCEDURE_ENTITY_INDEX dpei
                                                          ON dpe.id = dpei.procedureid AND (dpei.statusid = 18 OR dpei.statusid = 7)
                                                       JOIN EAIST_SHARD_1_3.D_PROCEDURE_VERSION dpv
                                                          ON dpv.entity_id = dpei.procedureid
                                                             AND dpv.deleted_date IS NULL
                                                       JOIN EAIST_SHARD_1_3.D_PROCEDURE_DATE dpd
                                                          ON     dpd.procedure_id = dpv.id
                                                             AND date_type = 'publicationDate') tbl1
                               FULL OUTER JOIN
                               (SELECT t1.id d_oos_ftp_procedure_id,
                                 t1.customer_id,
                                 t1.registry_number reg_number,
                                 TO_CHAR (t1.publication_date_time, 'DD.MM.YYYY') eis_publication_date,
                                 version eis_version,
                                 purchase_code_name eis_pcn,
                                 eis_sum
                          FROM EAIST_SHARD_1_3.d_oos_ftp_procedure t1
                                       JOIN
                                       (  SELECT MAX (t2.version) lp_version,
                                                 t2.registry_number,
                                                 t2.customer_id
                                            FROM EAIST_SHARD_1_3.d_oos_ftp_procedure t2
                                        GROUP BY t2.registry_number, t2.customer_id) lp
                                          ON     t1.version = lp.lp_version
                                             AND t1.customer_id = lp.customer_id
                                             AND t1.registry_number = lp.registry_number
                                       JOIN (  SELECT SUM (initial_sum) eis_sum, procedure_id
                                                 FROM EAIST_SHARD_1_3.D_OOS_FTP_PROCEDURE_LOTS
                                             GROUP BY procedure_id) sumlots
                                          ON sumlots.procedure_id = t1.id) tbl2
                                  ON     tbl1.customer_id = tbl2.customer_id
                                     AND tbl1.reg_number = tbl2.reg_number) tmain
                       LEFT JOIN EAIST_NSI.N_PARTICIPANT customer
                          ON customer.id = tmain.customer_id
                       LEFT JOIN EAIST_NSI.N_PARTICIPANT grbs
                          ON customer.parent_grbs = grbs.id
/

