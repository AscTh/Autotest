create view D_PROVISION_PERMISSION as
  SELECT
                    P.ID,
                    P.ENTITY_ID,
                    P.STATUS_ID,
                    P.CUSTOMER_ID,
                    U.USER_ID,
                    U.ACTION_CODE,
                    U.TARGET_CODE,
                    NP.FULL_NAME
                    FROM D_PROVISION P
                    INNER JOIN USER_TARGET_ACTIONS_ORG U ON P.CUSTOMER_ID = U.ORGANIZATION_ID
                    INNER JOIN N_PARTICIPANT NP ON NP.ID = U.ORGANIZATION_ID
                    WHERE P.DELETED_DATE IS NULL AND P.IS_ACTUAL = 1
/

